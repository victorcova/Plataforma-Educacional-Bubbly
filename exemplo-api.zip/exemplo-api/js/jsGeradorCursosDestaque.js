// CURSOS EM DESTAQUE CARDS API
const urlLocal = 'js/apiCursosDestaque.json'; // URLLocal LOCAL

const optionsLocal = {
    method: 'GET',
    mode: 'cors',
    cache: 'default'
}


    // let testeIMG = document.getElementById('carouselInner');
    
    // [1,2,3,4,5,6].forEach((data,index)=>{
    //     const image = `<div class="carousel-item ${index ? '': 'active'}">
    //     <img src="img/bubbly-imgs/tag_cursos/avatar-empreendedorismo.jpg" class="d-block w-100" alt="...">
    //     </div>`;
    //     testeIMG.innerHTML += image;
    // })
    


fetch(urlLocal, optionsLocal) // fez a promise
.then(response => { // pega a resposta da promessa e...
    console.log('RESPOSTA EM JSON:\n',response); // Resposta em formato JSON
    response.json() // Método JSON para transformar os dados para Objetos JS
    .then(dados => { // faz outra promise
        console.log('RESPOSTA CONVERTIDA PARA OBJETO:\n',dados);
        const cursos = dados.cursos; // "dados" é um objeto que vai receber data (que vem lá do JSON)
        const nome_curso = dados.nome_curso; // outro exemplo
        console.log('RESPOSTA EM ARRAY VINDA DO OBJETO CAPTANDO O ATRIBUTO DADOS:\n',cursos);
        console.log('RESPOSTA EM ARRAY VINDA DO OBJETO CAPTANDO O ATRIBUTO PAGE (EXEMPLO):\n',nome_curso);

        //EXIBIR CURSOS EM DESTAQUE                
        for (let i = 0; i < cursos.length; i++) {
            
            let carouselInner = document.getElementById('carouselInner');                    


            let carouselActiveOrItem = document.createElement('div');
            carouselActiveOrItem.setAttribute('class',`carousel-item ${i ? '': 'active'}`);

            carouselInner.appendChild(carouselActiveOrItem);

            let card = document.createElement('div')            
            card.setAttribute('class','card');
            card.setAttribute('data-aos','fade-up');
            card.setAttribute('data-aos-duration','500');            
            carouselActiveOrItem.appendChild(card);

            let divImg = document.createElement('div')            
            divImg.setAttribute('class','img-wrapper');
            card.appendChild(divImg);

            let imgAvatarCurso = document.createElement('img');
            imgAvatarCurso.setAttribute('class','card-img-top');            
            let imgAtual = cursos[i].avatar;
            imgAvatarCurso.setAttribute('src', imgAtual);                        
            let altCursoAtual = cursos[i].nome_curso;
            imgAvatarCurso.setAttribute('alt', altCursoAtual);
            divImg.appendChild(imgAvatarCurso);

            let cardBody = document.createElement('div');
            cardBody.setAttribute('class','card-body');
            card.appendChild(cardBody);            

            let h5TitCurso = document.createElement('h5');
            h5TitCurso.setAttribute('class','card-title pb-4');
            h5TitCurso.setAttribute('style','font-weight: 800; text-transform: uppercase; color:black');
            let idTitCurso = 'idTitCurso'+[i];
            h5TitCurso.setAttribute('id',idTitCurso);
            cardBody.appendChild(h5TitCurso);
            document.getElementById(idTitCurso).append(`${cursos[i].nome_curso}`);

            let ulInfoCurso = document.createElement('ul');
            ulInfoCurso.setAttribute('class','list-group');
            let idUlInfoCurso = 'idUlInfoCurso'+[i];
            ulInfoCurso.setAttribute('id',idUlInfoCurso);
            cardBody.appendChild(ulInfoCurso);            
            
            let liRatingCurso = document.createElement('li');
            liRatingCurso.setAttribute('class','list-group-item pb-2 text-mutted');
            let idLiRatingCurso = 'rating'+[i];
            liRatingCurso.setAttribute('id',idLiRatingCurso);
            ulInfoCurso.appendChild(liRatingCurso);
            document.getElementById(idLiRatingCurso).append(`Avaliação: ${cursos[i].rating}/5.0`);

            let liQtdAulasCurso = document.createElement('li');
            liQtdAulasCurso.setAttribute('class','list-group-item pb-2 text-mutted');
            let idLiQtdAulasCurso = 'qtdAulas'+[i];
            liQtdAulasCurso.setAttribute('id',idLiQtdAulasCurso);
            ulInfoCurso.appendChild(liQtdAulasCurso);
            document.getElementById(idLiQtdAulasCurso).append(`Quantidade: ${cursos[i].qtd_aulas} aulas`);

            let liNomeProfCurso = document.createElement('li');
            liNomeProfCurso.setAttribute('class','list-group-item pb-2 text-mutted');
            let idNomeProfCurso = 'idNomeProfCurso'+[i];
            liNomeProfCurso.setAttribute('id',idNomeProfCurso);
            ulInfoCurso.appendChild(liNomeProfCurso);
            document.getElementById(idNomeProfCurso).append(`Professor(a): ${cursos[i].nome_prof}`);
            
            let pDescricao = document.createElement('p')
            pDescricao.setAttribute('class','card-text pt-3 ml-1 text-mutted');
            pDescricao.setAttribute('style','text-align: left; font-weight: 300');
            let idDescricao = 'idDescricao'+[i];
            pDescricao.setAttribute('id',idDescricao);
            cardBody.appendChild(pDescricao);    
            document.getElementById(idDescricao).append(`${cursos[i].descr_curso}`);

            let btEmenta = document.createElement('button');
            btEmenta.setAttribute('type','button');
            btEmenta.setAttribute('class','btn btn-tomato me-2 float-end');
            cardBody.appendChild(btEmenta);
            btEmenta.innerHTML = "Ver Cursos";
                            
        }
    })
})

.catch(err => {
    console.log(err, "ERRO!")
})